#!/usr/bin/python


from gurobipy import *

def solve(nStudents, nTutorials, nTeams, groups, preferences, l, u):

    model = Model("tutorials")

    # Please use and adapt (no renaming!) the following variables:
    
    x = {}
    for s in range(nStudents):
        for t in range(nTutorials):
            # should have value 1 if student s is assigned to tutorial t and value 0 otherwise
            x[s,t] = model.addVar(  name="x_"+str(s)+"_"+str(t))
    y={}
    for t in range(nTutorials):
        # should have value 1 if tutorial t takes place and value 0 otherwise
        y[t] = model.addVar(  name="y_" +str(t) )

    # end of given variables; you can introduce your own variables but make sure that the above variables attain values as stated in the comments



    def printSolution():
        if model.status == GRB.status.OPTIMAL:
            for s in range(nStudents):
                for t in range(nTutorials):
                    if x[s,t].x == 1:
                        print('Student %s geht in Tutorium %s .' % (s,  t))
        else:
            print('No solution')


    #Solve
    model.optimize()
#    printSolution()


 